package com.dubbo.test.api;

/**
 * 监控api
 *
 * @version 1.0
 * @since 2020 /11/4 20:14
 */
public interface MonitorB {

  /**
   * requestA
   *
   * @version 1.0.0
   * @since 2020年11月4日 下午8:22:51
   */
  void requestA();

  /**
   * requestB
   *
   * @version 1.0.0
   * @since 2020年11月4日 下午8:22:51
   */
  void requestB();

  /**
   * requestC
   *
   * @version 1.0.0
   * @since 2020年11月4日 下午8:22:51
   */
  void requestC();
}
