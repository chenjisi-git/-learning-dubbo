package com.dubbo.test.provider;

import com.alibaba.dubbo.config.annotation.Service;
import com.dubbo.test.api.MonitorB;

import javax.annotation.PostConstruct;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * @version 1.0
 * @since 2020/11/4 20:27
 */
@Service
public class ServiceImpl implements MonitorB {
  private static final CopyOnWriteArrayList LIST_A = new CopyOnWriteArrayList();
  private static final CopyOnWriteArrayList LIST_B = new CopyOnWriteArrayList();
  private static final CopyOnWriteArrayList LIST_C = new CopyOnWriteArrayList();

  @Override
  public void requestA() {
    LIST_A.add(sleep());
    if (LIST_A.size() > 2000) {
      LIST_A.remove(0);
    }
  }

  @Override
  public void requestB() {
    LIST_B.add(sleep());
    if (LIST_B.size() > 2000) {
      LIST_B.remove(0);
    }
  }

  @Override
  public void requestC() {
    LIST_C.add(sleep());
    if (LIST_C.size() > 2000) {
      LIST_C.remove(0);
    }
  }

  @PostConstruct
  void init() {
    final int t90 = (int) (0.9 * 2000);
    final int t99 = (int) (0.99 * 2000);
     new Timer()
        .schedule(
            new TimerTask() {
              @Override
              public void run() {
                if(LIST_A.size()>=2000){
                  System.out.println(">>>>>>>>>>>请求A: t90:" + LIST_A.get(t90 - 1));
                  System.out.println(">>>>>>>>>>>请求A: t99:" + LIST_A.get(t99 - 1));
                }
                if(LIST_B.size()>=2000){
                  System.out.println(">>>>>>>>>>>请求B: t90:" + LIST_B.get(t90 - 1));
                  System.out.println(">>>>>>>>>>>请求B: t99:" + LIST_B.get(t99 - 1));
                }
                if(LIST_C.size()>=2000){
                  System.out.println(">>>>>>>>>>>请求C: t90:" + LIST_C.get(t90 - 1));
                  System.out.println(">>>>>>>>>>>请求C: t99:" + LIST_C.get(t99 - 1));
                }
              }
            },
            1000 * 5,
            5000);
  }

  // 具体操作
  private long sleep() {
    final long start = System.currentTimeMillis();
    try {
      Thread.sleep(new Random().nextInt(100));
    } catch (final InterruptedException e) {
      e.printStackTrace();
    }
    final long end = System.currentTimeMillis();
    return end - start;
  }
}
