package com.dubbo;

import com.alibaba.dubbo.common.extension.Activate;
import com.alibaba.dubbo.rpc.*;

/**
 * xxxx
 *
 * @version 1.0
 * @since 2020/11/4 21:50
 */
@Activate
public class TransportIPFilter implements Filter {
  @Override
  public Result invoke(final Invoker<?> invoker, final Invocation invocation) throws RpcException {
    Result result = null;
    try {
      final String clientIp = RpcContext.getContext().getRemoteHost();
      final long start=System.currentTimeMillis();
      result = invoker.invoke(invocation);
      final long end=System.currentTimeMillis();
      System.out.println("请求耗费时间:"+(end-start));
    } catch (final Exception e) {
      // TODO: handle exception
    }

    return result;
  }
}
