package com.dubbo.test.provider;

import com.alibaba.dubbo.config.annotation.Service;
import com.dubbo.test.api.MonitorA;

/**
 * @version 1.0
 * @since 2020/11/4 20:27
 */
@Service
public class ServiceImpl implements MonitorA {

  @Override
  public void request() {
    System.out.println("我是服务A");
  }
}
