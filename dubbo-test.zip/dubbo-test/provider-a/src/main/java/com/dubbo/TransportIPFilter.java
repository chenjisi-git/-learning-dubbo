package com.dubbo;

import com.alibaba.dubbo.common.extension.Activate;
import com.alibaba.dubbo.rpc.*;

/**
 * xxxx
 *
 * @version 1.0
 * @since 2020/11/4 21:50
 */
@Activate
public class TransportIPFilter implements Filter {
  @Override
  public Result invoke(Invoker<?> invoker, Invocation invocation) throws RpcException {
    Result result = null;
    try {
      String clientIp = RpcContext.getContext().getRemoteHost();
      result = invoker.invoke(invocation);
      System.out.println("远程地址ip->" + clientIp);
    } catch (Exception e) {
      // TODO: handle exception
    }
    return result;
  }
}
