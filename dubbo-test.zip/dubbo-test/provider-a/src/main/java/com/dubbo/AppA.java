package com.dubbo;

import com.alibaba.dubbo.config.spring.context.annotation.EnableDubbo;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * 启动类
 *
 * @version 1.0
 * @since 2020/11/4 20:23
 */
@EnableDubbo
@SpringBootApplication
public class AppA {
  public static void main(final String[] args) {
    SpringApplication.run(AppA.class, args);
  }
}
