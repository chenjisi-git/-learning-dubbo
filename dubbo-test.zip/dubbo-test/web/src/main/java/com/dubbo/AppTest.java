package com.dubbo;

import com.alibaba.dubbo.config.annotation.Reference;
import com.dubbo.test.api.MonitorA;
import com.dubbo.test.api.MonitorB;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.stream.IntStream;

/**
 * @version 1.0
 * @since 2020/11/4 20:47
 */
@RunWith(SpringRunner.class)
@SpringBootTest
public class AppTest {

  @Reference private MonitorA monitorA;
  @Reference private MonitorB monitorB;

  public static ExecutorService fixedThreadPool = Executors.newFixedThreadPool(30);

  @Test
  public void requestA() {
    monitorA.request();
    monitorB.requestA();
  }

  @Test
  public void requestB() throws InterruptedException {
    IntStream.range(0,10).forEach(v->fixedThreadPool.execute(new DoRequestA()));
    IntStream.range(0,10).forEach(v->fixedThreadPool.execute(new DoRequestB()));
    IntStream.range(0,10).forEach(v->fixedThreadPool.execute(new DoRequestC()));
    Thread.sleep(1000 * 60* 10);
  }

  class DoRequestA implements Runnable{
    public void run() {
      for (;;){
        monitorB.requestA();
      }
    }
  }
  class DoRequestB implements Runnable{
    public void run() {
      for (;;){
        monitorB.requestB();
      }
    }
  }
  class DoRequestC implements Runnable{
    public void run() {
      for (;;){
        monitorB.requestC();
      }
    }
  }
}
