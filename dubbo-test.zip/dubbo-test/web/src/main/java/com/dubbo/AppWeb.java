package com.dubbo;

import com.alibaba.dubbo.config.annotation.Reference;
import com.dubbo.test.api.MonitorA;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * 启动类
 *
 * @version 1.0
 * @since 2020/11/4 20:23
 */
@RestController
@SpringBootApplication
public class AppWeb {
  public static void main(final String[] args) {
    SpringApplication.run(AppWeb.class, args);
  }

  @Reference private MonitorA monitorA;

  @GetMapping("test")
  public Object test() {
    System.out.println("test");
    monitorA.request();
    return "ok";
  }
}
